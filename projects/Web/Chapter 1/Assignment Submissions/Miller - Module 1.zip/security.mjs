function getInfo() {

    var browser = navigator.appName;
    var online = navigator.onLine;
    var platform = navigator.platform;
    var height = screen.height + " pixels";
    var width = screen.width + " pixels";
    var pixels = screen.pixelDepth + " bits per pixel";

    var data = [browser, online, platform, height, width, pixels];

    for (i = 0; i < data.length; i++) { //for statement that will increment by 1 every iteration NTE length of data array
        document.getElementsByClassName("field")[i].innerHTML = data[i]; //get class name field that increments with i and writes data to innerHTML
    }

    //since I dont like the lower case t in true, I fixed it to a capital.
    if (online.value = true){
        document.getElementById("online").innerHTML = "True";
    } else {
        document.getElementById("online").innerHTML = "False";
    }
}